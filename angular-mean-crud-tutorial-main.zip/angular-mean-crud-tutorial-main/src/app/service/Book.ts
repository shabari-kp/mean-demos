export class Book {
    _id!: String;
    name!: String;
    price!: String;
    description!: String;
}